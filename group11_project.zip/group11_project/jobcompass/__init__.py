"""JobCompass: a local, explainable job search course project."""
__version__ = "1.0.0"
